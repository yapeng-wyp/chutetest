<!-- Format -->
<div class="wcpt-editor-row-option">
  <label>
  Format
    <small>
      F j, Y (March 10, 2001) <br>
      M j, Y (Mar 10, 2001) <br>
      j F, Y (10 March, 2001) <br>
      j M, Y (10 Mar, 2001) <br>
      m/d/Y (03/10/2001) <br>
      d/m/Y (10/03/2001) <br>
      <a href="https://www.php.net/manual/en/function.date.php" target="_blank">More info</a>
    </small>
  </label>
  <input type="text" wcpt-model-key="format">
</div>

<!-- style -->
<?php include( 'style/common.php' ); ?>

<!-- condition -->
<?php include( 'condition/outer.php' ); ?>
