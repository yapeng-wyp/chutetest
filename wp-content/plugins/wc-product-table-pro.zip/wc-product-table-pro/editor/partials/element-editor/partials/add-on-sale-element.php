<h2>Add On-Sale Element</h2>
<?php
  wcpt_elm_type_list( array(
    'Text',
    'Icon [pro]',
    'Media Image [pro]',
  ) );
?>
