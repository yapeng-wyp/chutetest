<h2>Add Price Variable Element</h2>
<?php
  wcpt_elm_type_list( array(
    'Lowest price',
    'Highest price',
    'Text',
    'Space',
    'HTML',
    'Dot',
    // 'Bang',
    'Icon [pro]',
    'Media Image [pro]',
  ) );
?>
