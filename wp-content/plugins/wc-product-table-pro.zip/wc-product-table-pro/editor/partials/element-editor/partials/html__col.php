<div class="wcpt-editor-row-option">
  <label>HTML</label>  
  <textarea wcpt-model-key="html"></textarea>
  <label>
    <?php wcpt_general_placeholders__print_placeholders(); ?>        
  </label>    
</div>

<!-- style -->
<?php include( 'style/common.php' ); ?>

<!-- condition -->
<?php include( 'condition/outer.php' ); ?>
