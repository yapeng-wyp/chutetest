<h2>Add Responsive Navigation Element</h2>
<?php
  wcpt_elm_type_list( array(
    'Result Count',
    'Filter Modal',
    'Sort Modal',
    'Clear Filters',
    'Text',
    'HTML',
    'Icon',
  ) );
?>
