<h2>Add ToolTip Element</h2>
<?php
  wcpt_elm_type_list( array(
    // Structure
    'Text',
    'HTML',
    'Space',
    'Dot',
    'Icon',
    'Media Image',
  ) );
?>
