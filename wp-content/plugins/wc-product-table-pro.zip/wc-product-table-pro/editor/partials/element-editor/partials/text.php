<div class="wcpt-editor-row-option">
  <label>Text</label>
  <textarea wcpt-model-key="text"></textarea>
</div>

<?php
  include( 'style/common.php' );
?>
