<h2>Add Element</h2>
<?php
  wcpt_elm_type_list( array(
    'Text',
    'HTML',
    'Dot',
    // 'Bang',
    'Space',
    'Icon [pro]',
    'Media image [pro]',
  ) );
?>
