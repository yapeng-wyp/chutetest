<h2>Add Element</h2>
<?php
  wcpt_elm_type_list( array(
    'Text__Col',
    'HTML__Col',
    'Dot__Col',
    'Space__Col',
    'Tooltip [pro]',
    'Icon__Col [pro]',
    'Media Image__Col [pro]',
  ) );
?>
