<div class="wcpt-editor-row-style-options wcpt-editor-row-option" wcpt-model-key="style">
  <div class="wcpt-wrapper" wcpt-model-key="[id]">
    <?php include( 'price-style.php' ); ?>
  </div>
</div>
