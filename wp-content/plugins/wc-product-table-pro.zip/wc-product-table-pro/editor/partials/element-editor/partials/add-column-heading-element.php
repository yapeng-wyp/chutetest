<h2>Add Element To Column Heading</h2>
<?php
  wcpt_elm_type_list( array(
    'Text',
    'HTML',
    'Space',
    'Dot',
    'ToolTip [pro]',
    'Sorting [pro]',
    'Icon [pro]',
    'Media image [pro]',
  ) );
?>
