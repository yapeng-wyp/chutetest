<h2>Add Price Element</h2>
<?php
  wcpt_elm_type_list( array(
    'Text',
    'Price__Variation',
    'Select__Variation',
    'Availability',
    'Media Image',
    'Icon',
  ) );
?>
