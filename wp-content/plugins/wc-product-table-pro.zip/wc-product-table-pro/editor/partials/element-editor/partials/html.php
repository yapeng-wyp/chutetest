<div class="wcpt-editor-row-option">
  <label>HTML</label>
  <textarea wcpt-model-key="html"></textarea>
</div>

<!-- style -->
<?php include( 'style/common.php' ); ?>
