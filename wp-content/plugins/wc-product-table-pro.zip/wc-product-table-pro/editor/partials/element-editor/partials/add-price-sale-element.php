<h2>Add Price Sale Element</h2>
<?php
  wcpt_elm_type_list( array(
    'Sale price',
    'Regular price__On sale',
    'Lowest price',
    'Highest price',
    'Text',
    'Space',
    'HTML',
    'Dot',
    // 'Bang',
    'Icon [pro]',
    'Media Image [pro]',
  ) );
?>
