<div class="wcpt-editor-row-option">
  <label>Text</label>
  <textarea wcpt-model-key="text"></textarea>
  <label>
    <?php wcpt_general_placeholders__print_placeholders(); ?>        
  </label>      
</div>

<!-- style -->
<?php include( 'style/common.php' ); ?>

<!-- condition -->
<?php include( 'condition/outer.php' ); ?>
