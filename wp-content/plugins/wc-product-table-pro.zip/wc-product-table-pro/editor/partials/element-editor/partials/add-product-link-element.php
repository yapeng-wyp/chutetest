<h2>Add Element</h2>
<?php
  wcpt_elm_type_list( array(
    'Text',
    'HTML',
    'Dot',
    'Space',
    'Icon [pro]',
    'Media image [pro]',
    'Custom Field',
    'Price',
    'SKU',
  ) );
?>
