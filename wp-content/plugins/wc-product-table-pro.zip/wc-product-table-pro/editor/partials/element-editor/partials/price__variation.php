<!-- style -->
<?php include( 'style/common.php' ); ?>

<div class="wcpt-editor-row-option" wcpt-model-key="style">

  <div class="wcpt-editor-row-option wcpt-toggle-options wcpt-row-accordion" wcpt-model-key="[id] ins">

    <span class="wcpt-toggle-label">
      Style for Sale Price
      <?php echo wcpt_icon('chevron-down'); ?>
    </span>

    <?php require( 'style/common-props.php' ); ?>

  </div>

</div>
