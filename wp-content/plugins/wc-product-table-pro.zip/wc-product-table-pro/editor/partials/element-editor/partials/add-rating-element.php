<h2>Add Rating Element</h2>
<?php
  wcpt_elm_type_list( array(
    'Rating number',
    'Rating stars',
    'Review count',
    'Text',
    'Space',
    'HTML',
    'Dot',
    // 'Bang',
    'Icon',
    'Media image [pro]',
  ) );
?>
