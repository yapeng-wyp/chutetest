<div class="wcpt-editor-row-option">
  <label>
    <input type="checkbox" wcpt-model-key="heading_enabled" /> 
    Enable checkbox in column heading
  </label>
</div>

<!-- condition -->
<?php include( 'condition/outer.php' ); ?>
