<div class="wcpt-editor-row-style-options wcpt-editor-row-option" wcpt-model-key="style">

  <div wcpt-model-key="[id]">

    <!-- width -->
    <div class="wcpt-editor-row-option">
      <label>
        Space width
        <small>Create space between adjacent elments. Default: 4px</small>
      </label>
      <input type="text" wcpt-model-key="width" />
    </div>

  </div>

</div>

<!-- condition -->
<?php include( 'condition/outer.php' ); ?>
