<!-- background-color -->
<div class="wcpt-editor-option-row">
  <label>Background color</label>
  <input type="text" wcpt-model-key="background-color" class="wcpt-color-picker">
</div>

<!-- font-color -->
<div class="wcpt-editor-option-row">
  <label>Font color</label>
  <input type="text" wcpt-model-key="color" placeholder="#000" class="wcpt-color-picker">
</div>
