<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="wcpt-loading-screen"></div>
