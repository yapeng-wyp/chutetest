<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

echo $product->get_id();
