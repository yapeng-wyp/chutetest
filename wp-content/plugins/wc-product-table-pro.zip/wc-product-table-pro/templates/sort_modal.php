<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<a 
	class="wcpt-rn-button wcpt-rn-sort <?php echo $html_class;?>" 
	href="javascript:void(0)" 
	data-wcpt-modal="sort" 
>
	<?php echo wcpt_parse_2( $label ); ?>
</a>
