<?php
include( 'regular_price.php' );