<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<table class="wcpt-table wcpt-table-<?php echo $table_id;?>">
