<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<div class="wcpt-table-scroll-wrapper-outer wcpt-device-<?php echo $device; ?>">
