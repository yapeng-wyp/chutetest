<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?><span class="wcpt-space <?php echo $html_class; ?>"></span><?php
