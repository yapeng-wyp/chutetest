<td 
  class="<?php echo apply_filters('wcpt_cell_html_class', 'wcpt-cell wcpt-' . $column['cell']['id'] ); ?>"
  data-wcpt-column-index="<?php echo $column_index; ?>"
>